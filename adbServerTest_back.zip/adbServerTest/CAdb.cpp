#include "CAdb.h"
#include "adb_func.h"

CAdb::CAdb(const char* _name_serial)
	:name_serial(_name_serial), isok(false), m_atransport(NULL), retBuff(NULL)
{
	atransport* temp =  get_device(name_serial.c_str());
	if (temp)
	{
		if (temp->kicked){ return; }//�Ѿ��޳��޷�ʹ��
		if (!temp->ref_count){
			transport_registration_func(temp, 1);	//ע��
		}
		temp->connectCount++;	//����������

		BipBuffer bip = new BipBufferRec();
		bip_buffer_init(bip);
		retBuff = bip;

		isok = true;
		m_atransport = (void*)temp;
	}
}

CAdb::CAdb(CAdb& parent) //�����Ӽ�
	:name_serial(parent.get_serial()), m_atransport(parent.m_atransport), retBuff(NULL)
{
	if (!m_atransport)
	{
		atransport* temp = (atransport*)m_atransport;
		if (temp->kicked){ //�Ѿ��޳��޷�ʹ��
			m_atransport = NULL;
			return; }
		++(temp->connectCount);	//����������
		BipBuffer bip = new BipBufferRec();
		bip_buffer_init(bip);
		retBuff = bip;

		isok = true;
	}
}

CAdb::~CAdb()
{
	int nCount = -1;
	atransport* t = (atransport*)m_atransport;
	m_atransport = NULL;
	if (t)
	{
		//�رյ�ǰ���ӵ�ͨ��
		BipBuffer bip = (BipBuffer)retBuff;
		retBuff = 0;
		local_socket_close(bip, t);
		nCount = (--(t->connectCount));
	}
	
	if (nCount == 0)//�����ײ�����߳�
	{
		transport_registration_func(t, 0);	//ֹͣ
	}
}

void CAdb::InitAdb(){
	adb_auth_init();
	usb_vendors_init();
}

void CAdb::FindDevices(){
	find_devices();
}

void CAdb::GetDevicesNameList(sstring& ret){
	get_device_name_list(ret);
}

bool CAdb::IsOk()
{
	return isok;
}

bool CAdb::IsUsbClose(){
	atransport* t = (atransport*)m_atransport;
	if (t){
		return (t->kicked != 0);//usb�豸�Ѿ��Ͽ�
	}
	return true;
}

void CAdb::UsbClose(){
	atransport* t = (atransport*)m_atransport;
	if (t){
		Close();
		remote_close(t);
	}
}

bool CAdb::IsClose(){
	if (!IsUsbClose()){//û�Ͽ��ж��� ͨ���Ƿ��Ѿ��ر�
		BipBuffer bip = (BipBuffer)retBuff;
		if (bip){
			return (bip->biptype == bipbuffer_close);
		}
	}
	return true;
}

void CAdb::Close(){
	BipBuffer bip = (BipBuffer)retBuff;
	atransport* t = (atransport*)m_atransport;
	if (bip && t){
		if (bip->biptype == bipbuffer_close){
			//�ر�״̬ ��ֱ�Ӹ�ֵ
		}
		else {
			while (bip->remote_id == 0 && (bip->biptype != bipbuffer_close)){//�Ѿ����͹���Ϣ��ȥ ��ôҪ�ȴ���Ϣ����
				adb_sleep_ms(10);
			}
			if (bip->remote_id > 0){
				remote_socket_close(bip->remote_id, (int)bip, t);
			}
			while (bip->biptype != bipbuffer_close){
				adb_sleep_ms(10);
			}
		}
	}
}

bool CAdb::IsOnline(){
	atransport* t = (atransport*)m_atransport;
	if (t){
		return (t->connection_state == CS_DEVICE && t->online != 0);
	}
	return false;
}

sstring CAdb::get_serial(){
	return name_serial;
}

bool CAdb::Shell_send(const char* data){
	int ret = 0;
	if (m_atransport && retBuff && data[0]){
		BipBuffer bip = (BipBuffer)retBuff;
		ret = adb_shell_send(bip, (atransport*)m_atransport, data, strlen(data));
	}
	return (ret == 1);
}

void CAdb::Shell_recv(sstring& ret, int wait_time /*= 0*/){
	BipBuffer bip = (BipBuffer)retBuff;
	if (bip){
		adb_shell_recv(bip, (atransport*)m_atransport, ret, wait_time);
	}
}

int  CAdb::forwardconnect(const char* data){
	return adb_forward_connect(data, (BipBuffer)retBuff, (atransport*)m_atransport);
}

int  CAdb::forwardwrite(unsigned char* data, int len){
	return adb_forward_write(data, len, (BipBuffer)retBuff, (atransport*)m_atransport);
}

int  CAdb::forwardread(unsigned char* data, int len, int wait_times /*= 0*/){
	int ret = adb_forward_read(data, len, (BipBuffer)retBuff, (atransport*)m_atransport, wait_times);
	return ret;
}

int  CAdb::forwarddisconnect(){
	return adb_forward_disconnect((BipBuffer)retBuff, (atransport*)m_atransport);
}
//
//void CAdb::forwardTest(){
//	//"shell:LD_LIBRARY_PATH=/data/local/tmp /data/local/tmp/ctest -Q 100 -P 720x1280@720x1280/0 -S -n ctest"
//	//"localabstract:ctest"
//	CAdb adbforward(*this);
//
//	const char* shellcomm = "shell:LD_LIBRARY_PATH=/data/local/tmp /data/local/tmp/ctest -Q 100 -P 720x1280@720x1280/0 -S -n ctest";
//	const char* forwardcomm = "localabstract:ctest";
//
//	BipBuffer bip = (BipBuffer)retBuff;
//	if (adb_shell_send(bip, (atransport*)m_atransport, shellcomm, strlen(shellcomm)) == 1)
//	{
//		sstring retss;
//		adb_shell_recv(bip, retss, 2);
//		printf(retss.c_str());
//		if (adbforward.forwardconnect(forwardcomm) == 1)
//		{
//			unsigned char buff[8192];
//			int nlen = adbforward.forwardread(buff, 8192);
//			printf((char*)buff);
//			adbforward.forwarddisconnect();
//		}
//	}
//}

bool  CAdb::sync_push(const char* lpath, const char* rpath){
	BipBuffer bip = (BipBuffer)retBuff;
	atransport* t = (atransport*)m_atransport;
	int ret = 1;
	if (bip && t){
		ret = adb_sync_push(lpath, rpath, bip, t);
	}
	return (ret == 0);
}
bool  CAdb::sync_pull(const char* rpath, const char* lpath){
	BipBuffer bip = (BipBuffer)retBuff;
	atransport* t = (atransport*)m_atransport;
	int ret = 1;
	if (bip && t){
		ret = adb_sync_pull(rpath, lpath, bip, t);
	}
	return (ret == 0);
}

bool   CAdb::sync_push_buffer(unsigned char* buffer, size_t len, const char* rpath){
	BipBuffer bip = (BipBuffer)retBuff;
	atransport* t = (atransport*)m_atransport;
	int ret = 1;
	if (bip && t){
		ret = adb_sync_push_buffer(buffer, len, rpath, bip, t);
	}
	return (ret == 0);
}

bool   CAdb::sync_pull_buffer(bufferstream &buffer, size_t &len, const char* rpath){	//return is the recv length
	BipBuffer bip = (BipBuffer)retBuff;
	atransport* t = (atransport*)m_atransport;
	int ret = 1;
	if (bip && t){
		ret = adb_sync_pull_buffer(buffer, len, rpath, bip, t);
	}
	return (ret == 0);
}