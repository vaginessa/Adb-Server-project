#include <Windows.h>
#include <win32_adb.h>
#include "adb_func.h"
#include "adb_auth.h"	//��׿ ��Կ
#include <map>

#include "file_sync_service.h"

//��־���
void show_log(const char* _Format, ...){
	va_list marker = NULL;
	va_start(marker, _Format);
	int num_of_chars = _vscprintf(_Format, marker) + 1;
	char *log = (char*)malloc(num_of_chars);
	if (log){
		vsprintf(log, _Format, marker);
		OutputDebugStringA(log);
		free(log);
	}
	va_end(marker);
}

void show_apacket(const char* label, apacket* p){
	char *tag;
	char *x;
	unsigned count;
	int _duppmax = 32;

	switch (p->msg.command){
	case A_SYNC: tag = "SYNC"; break;
	case A_CNXN: tag = "CNXN"; break;
	case A_OPEN: tag = "OPEN"; break;
	case A_OKAY: tag = "OKAY"; break;
	case A_CLSE: tag = "CLSE"; break;
	case A_WRTE: tag = "WRTE"; break;
	case A_AUTH: tag = "AUTH"; break;
	default: tag = "????"; break;
	}
	int len = p->len ? p->len : p->msg.data_length;
	char* buff = "\0";
	if (len){
		buff = (char*)p->data;
	}
	show_log(" %s: %s arg0<%08x> arg1<%08x> data_length<%d> \n data:%s\n",
		label, tag, p->msg.arg0, p->msg.arg1, p->msg.data_length, buff);
}

atransportPtrList				atransport_free_list;	//���ϵ��豸�б�
adb_buff_mutex					atransport_free_mutex;	//��
bool atransport_is_free(atransport* t){
	bool isfree = true;
	if (t){
		adb_mutex_lock _lock(atransport_free_mutex);
		atransportPtrList::iterator it = atransport_free_list.find(t);
		isfree = (it != atransport_free_list.end());
	}
	return isfree;
}

void atransport_put(atransport* t){
	adb_mutex_lock _lock(atransport_free_mutex);
	if (t){ atransport_free_list.insert(t); }
}

void atransport_free(){
	adb_mutex_lock _lock(atransport_free_mutex);
	for (atransportPtrList::iterator it = atransport_free_list.begin(); it != atransport_free_list.end(); ++it){
		delete (*it);
	}
	atransport_free_list.clear();
}

/**************************************************************************/
/**************************************************************************/
/*****                                                                *****/
/*****    USB API				                                      *****/
/*****                                                                *****/
/**************************************************************************/
/**************************************************************************/

//��׿�豸
#define ADB_CLASS              0xff
#define ADB_SUBCLASS           0x42
#define ADB_PROTOCOL           0x1

#ifdef HAVE_BIG_ENDIAN
#define H4(x)	(((x) & 0xFF000000) >> 24) | (((x) & 0x00FF0000) >> 8) | (((x) & 0x0000FF00) << 8) | (((x) & 0x000000FF) << 24)
static inline void fix_endians(apacket *p)
{
	p->msg.command = H4(p->msg.command);
	p->msg.arg0 = H4(p->msg.arg0);
	p->msg.arg1 = H4(p->msg.arg1);
	p->msg.data_length = H4(p->msg.data_length);
	p->msg.data_check = H4(p->msg.data_check);
	p->msg.magic = H4(p->msg.magic);
}
#else
#define fix_endians(p) do {} while (0)
#endif

static adb_usb_mutex	usb_lock;// �б�������

adb_usb_mutex	log_lock;// ��־�����

//=========================================USB===========================================

unsigned host_to_le32(unsigned n)
{
	return n;
}


int is_adb_interface(int vid, int pid, int usb_class, int usb_subclass, int usb_protocol)
{
	unsigned i;
	for (i = 0; i < vendorIdCount; i++) {
		if (vid == vendorIds[i]) {
			if (usb_class == ADB_CLASS && usb_subclass == ADB_SUBCLASS &&
				usb_protocol == ADB_PROTOCOL) {
				return 1;
			}

			return 0;
		}
	}
	return 0;
}

int remote_read(apacket* p, atransport *t)
{
	if (usb_read(t->usb, &p->msg, sizeof(amessage))){
		D("remote usb: read terminated (message)\n");
		return -1;
	}

	fix_endians(p);

	if (check_header(p)) {
		D("remote usb: check_header failed\n");
		return -1;
	}

	if (p->msg.data_length) {
		if (usb_read(t->usb, p->data, p->msg.data_length)){
			D("remote usb: terminated (data)\n");
			return -1;
		}
	}

	if (check_data(p)) {
		D("remote usb: check_data failed\n");
		return -1;
	}

	return 0;
}

int remote_write(apacket* p, atransport *t)
{
	unsigned size = p->msg.data_length;

	//fix_endians(p);

	if (usb_write(t->usb, &p->msg, sizeof(amessage))) {
		D("remote usb: 1 - write terminated\n");
		return -1;
	}
	if (p->msg.data_length == 0) return 0;
	if (usb_write(t->usb, &p->data, size)) {
		D("remote usb: 2 - write terminated\n");
		return -1;
	}

	return 0;
}

void remote_close(atransport *t)
{
	if (!t){ return; }
	{	//remove map
		adb_mutex_lock	_lock(atransport_lock);
		sstring	sername(t->serial);
		devices_list.erase(sername);
	}
	t->kicked = 1;
	// Remove handle from the list
	adb_mutex_lock _lock(usb_lock);
	usb_close(t->usb);
	t->usb = 0;
}

void remote_kick(atransport *t)
{
	if (!t){ return; }
	t->kicked = 1;
	usb_kick(t->usb);
}


//==================================================�û��˲���=============================================================

int remote_read_user(apacket* &p, atransport *t)
{
	void* temp = NULL;
	if (adb_read(t->sfd, t->pair, temp)){
		D("remote local: read terminated (message)\n");
		return -1;
	}
	put_apacket(p, t);
	p = (apacket*)temp;

	//fix_endians(p);

	if (check_header(p)) {
		D("bad header: terminated (data)\n");
		return -1;
	}

	//if (adb_read(t->sfd, p->data, p->msg.data_length)){
	//	D("remote local: terminated (data)\n");
	//	return -1;
	//}

	if (check_data(p)) {
		D("bad data: terminated (data)\n");
		return -1;
	}
	return 0;
}

int remote_write_user(apacket* &p, atransport *t)
{
	void* temp = (void*)p;
	if (!temp){ 
		put_apacket(p, t);
		return -1; 
	}
	//fix_endians(p);

	if (adb_write(t->sfd, t->pair, temp)) {
		D("remote local: write terminated\n");
		put_apacket(p, t);
		return -1;
	}
	p = NULL;
	return 0;
}
//=======================================================================================================================

atransport* get_device(const char* name_serial){
	adb_mutex_lock	_lock(atransport_lock);
	devicesMap::iterator it = devices_list.find(name_serial);
	if (it == devices_list.end()){
		return NULL;
	}
	return it->second;
}

void get_device_name_list(sstring& retlist){
	adb_mutex_lock	_lock(atransport_lock);
	//atransport* t = NULL;
	for (devicesMap::iterator it = devices_list.begin(); it != devices_list.end(); it++)
	{
		//t = it->second;
		//if (t->connection_state == CS_DEVICE){
			retlist += it->first;
			retlist += "|";
		//}
	}
}

/**************************************************************************/
/**************************************************************************/
/*****                                                                *****/
/*****    �������ݽṹ ����		                                      *****/
/*****                                                                *****/
/**************************************************************************/
/**************************************************************************/

void bip_buffer_init(BipBuffer  buffer)
{
	//buffer->a_start = 0;
	//buffer->a_end = 0;
	//buffer->b_end = 0;
	buffer->fdin = 0;
	buffer->fdout = 0;
	buffer->last_apacket = NULL;
	buffer->biptype = bipbuffer_close;
	buffer->remote_id = 0;
	buffer->closed = 0;
	buffer->finshed = 0;
	buffer->ptrlist = new BipPtrList(0);	//�Զ��б�
}

void bip_buffer_close(BipBuffer  bip)
{
	bip->biptype = bipbuffer_close;
	bip->finshed = 1;
	bip->closed = 1;
}

void	bip_buffer_done(BipBuffer  bip)
{
	BIPD(("bip_buffer_done: %d->%d\n", bip->fdin, bip->fdout));
	if (bip){
		BipLpList temp = bip->ptrlist;
		bip->ptrlist = NULL;
		apacket* p = NULL;
		if (temp){
			while (temp->pop(p)){
				put_apacket(p);
			}
			delete temp;
		}
		p = (apacket*)bip->last_apacket;
		bip->last_apacket = NULL;
		put_apacket(p);
	}
}

int	bip_buffer_write(BipBuffer  bip, void* & _scr)
{
	D("bip_buffer_write: enter %d->%d addr %d\n", bip->fdin, bip->fdout, (int)_scr);

	int succ = 0;
	do{
		if (!bip->ptrlist){ return -1; }
		if (bip->closed) {
			errno = EPIPE;
			D("bip_buffer_write: closed %d->%d addr %d\n", bip->fdin, bip->fdout, (int)_scr);
			bip_buffer_close(bip);
			return -1;
		}
		//��������ֱ��д��
		if (bip->ptrlist->push(_scr)){//ֱ������д��
			_scr = NULL;//����ָ��� ȥ��ָ��
			succ = 1;
		}
	} while (!succ);
	D("bip_buffer_write: exit %d->%d addr %d\n", bip->fdin, bip->fdout, (int)_scr);
	return 0;
}

int	bip_buffer_read(BipBuffer  bip, void*& _dst)
{
	D("bip_buffer_read: enter %d->%d addr %d\n", bip->fdin, bip->fdout, (int)_dst);
	int succ = 0;
	do{
		if (!bip->ptrlist){ return -1; }
		if (bip->closed) {
			errno = EPIPE;
			D("bip_buffer_read: closed %d->%d addr %d\n", bip->fdin, bip->fdout, (int)_dst);
			bip_buffer_close(bip);
			return -1;
		}
		if (bip->ptrlist->pop(_dst)){//�ǿ������ ��ȡ ���� ���� �ȴ�
			succ = 1;
		}
	} while (!succ);
	D("bip_buffer_read: exit %d->%d addr %d\n", bip->fdin, bip->fdout, (int)_dst);
	return 0;
}


SocketPair  adb_socketpair()
{
	SocketPair  pair = new SocketPairRec();

	//pair = (SocketPair)malloc(sizeof(*pair));
	if (pair == NULL) {
		//D("adb_socketpair: not enough memory to allocate pipes\n");
		goto Fail;
	}

	bip_buffer_init(&pair->a2b_bip);
	bip_buffer_init(&pair->b2a_bip);

	pair->used = 2;
	pair->a_fd = 100;//��־ �豸��������Ϊ �� 1

	//-----------------�����������-------
	pair->a2b_bip.fdin = 1;
	pair->a2b_bip.fdout = 2;
	pair->b2a_bip.fdin = 2;
	pair->b2a_bip.fdout = 1;
	//------------------------------------
	return pair;

Fail:
	return NULL;
}

int	_fh_socketpair_close(int f, SocketPair  _pair)
{
	if (_pair) {
		SocketPair  pair = _pair;

		bip_buffer_close(&pair->b2a_bip);
		bip_buffer_close(&pair->a2b_bip);

		if (pair->used == 0){
			bip_buffer_done(&pair->b2a_bip);
			bip_buffer_done(&pair->a2b_bip);
			pair->a_fd = NULL;
		}
	}
	return 0;
}

int	_fh_socketpair_lseek(int  f, int pos, int  origin)
{
	//errno = ESPIPE;
	return -1;
}

int	_fh_socketpair_read(int f, SocketPair  _pair, void*& _dst)
{
	SocketPair  pair = _pair;
	BipBuffer   bip;
	if (!pair)
		return -1;

	if (f == pair->a_fd)
		bip = &pair->b2a_bip;
	else
		bip = &pair->a2b_bip;

	return bip_buffer_read(bip, _dst);
}

int	_fh_socketpair_write(int f, SocketPair  _pair, void*& _scr)
{
	SocketPair  pair = _pair;
	BipBuffer   bip;
	if (!pair)
		return -1;

	if (f == pair->a_fd)
		bip = &pair->a2b_bip;
	else
		bip = &pair->b2a_bip;

	return bip_buffer_write(bip, _scr);
}

int  adb_read(int f, SocketPair  _pair, void*& _dst)
{
	if (_pair == NULL) {
		return -1;
	}
	return _fh_socketpair_read(f, _pair, _dst);
}


int  adb_write(int f, SocketPair  _pair, void* &_scr)
{
	if (_pair == NULL) {
		return -1;
	}
	return _fh_socketpair_write(f, _pair, _scr);
}


int  adb_lseek(int  fd, int  pos, int  where)
{
	if (!fd) {
		return -1;
	}
	return _fh_socketpair_lseek(fd, pos, where);
}

int  adb_close(int f, SocketPair  _pair)
{
	if (!_pair) {
		return -1;
	}
	//D("adb_close: %s\n", f->name);
	_fh_socketpair_close(f, _pair);
	return 0;
}

apacket *get_apacket(atransport *t /*= NULL*/)
{
	apacket *p = NULL;
	if (t){
		if (t->loop_to_use_apacket){	//�Ի��յ����ݰ��ظ����� ����Ƶ���Ĵ����ͷ���Դ
			t->loop_to_use_apacket->pop(p);
		}
	}
	if (!p){
		p = (apacket *)malloc(sizeof(apacket));
	}
	if (p) {
		memset(p, 0, sizeof(apacket) - MAX_PAYLOAD);
	}
	return p;
}

void put_apacket(apacket* &p, atransport *t /*= NULL*/)
{
	if (t){
		if (t->kicked == 0 && t->loop_to_use_apacket){//����Ѿ��Ͽ��򲻻���ֱ���ͷ� �������
			t->loop_to_use_apacket->push(p);
			p = NULL;
			return;
		}
	}
	if (p){ free(p); }
	p = NULL;
}

int	read_packet(int f, SocketPair  _pair, apacket*& packet)
{
	if (_pair) {
		void* p = NULL;
		if (adb_read(f, _pair, p)) {//���ط�0Ϊ��
			return -1;
		}
		put_apacket(packet);
		packet = (apacket*)p;
		if (!packet){ return -1; }
	}else {
		return -1;
	}
	return 0;
}

int	write_packet(int f, SocketPair  _pair, apacket*& packet)
{
	if (_pair && packet){
		void* p = (void*)packet;
		if (adb_write(f, _pair, p)){//��0Ϊ��
			put_apacket(packet);
			return -1;
		}
		packet = NULL;
	}else{
		put_apacket(packet);
		return -1;
	}
	return 0;
}

int check_header(apacket *p)
{
	if (!p){ return -1; }
	if (p->msg.magic != (p->msg.command ^ 0xffffffff)) {
		//D("check_header(): invalid magic\n");
		return -1;
	}

	if (p->msg.data_length > MAX_PAYLOAD) {
		//D("check_header(): %d > MAX_PAYLOAD\n", p->msg.data_length);
		return -1;
	}

	return 0;
}

int check_data(apacket *p)
{
	unsigned count, sum;
	unsigned char *x;

	if (!p){ return -1; }

	count = p->msg.data_length;
	x = p->data;
	sum = 0;
	while (count-- > 0) {
		sum += *x++;
	}

	if (sum != p->msg.data_check) {
		return -1;
	}
	else {
		return 0;
	}
}


void handle_online(atransport *t)
{
	D("adb: online\n");
	t->online = 1;
}

void handle_offline(atransport *t)
{
	D("adb: offline\n");
	//Close the associated usb
	t->online = 0;
	//run_transport_disconnects(t);
}

void send_packet(apacket* &p, atransport *t)
{
	unsigned char *x;
	unsigned sum;
	unsigned count;

	p->msg.magic = p->msg.command ^ 0xffffffff;

	count = p->msg.data_length;
	x = (unsigned char *)p->data;
	sum = 0;
	while (count-- > 0){
		sum += *x++;
	}
	p->msg.data_check = sum;

	//print_packet("send", p);

	if (t == NULL) {
		D("Transport is null \n");
		// Zap errno because print_packet() and other stuff have errno effect.
		errno = 0;
		//fatal_errno("Transport is null");
	}

	if (write_packet(t->transport_socket, t->pair, p)){
		//fatal_errno("cannot enqueue packet on transport socket");
	}
}

void send_ready(unsigned local, unsigned remote, atransport *t)
{
	D("Calling send_ready \n");
	apacket *p = get_apacket(t);
	p->msg.command = A_OKAY;
	p->msg.arg0 = local;
	p->msg.arg1 = remote;
	send_packet(p, t);
}

void send_close(unsigned local, unsigned remote, atransport *t)
{
	//D("Calling send_close \n");
	apacket *p = get_apacket(t);
	p->msg.command = A_CLSE;
	p->msg.arg0 = local;
	p->msg.arg1 = remote;
	send_packet(p, t);
}

size_t fill_connect_data(char *buf, size_t bufsize)
{
	return snprintf(buf, bufsize, "host::") + 1;
}

void send_connect(atransport *t)
{
	D("Calling send_connect \n");
	apacket *cp = get_apacket(t);
	cp->msg.command = A_CNXN;
	cp->msg.arg0 = A_VERSION;
	cp->msg.arg1 = MAX_PAYLOAD;
	cp->msg.data_length = fill_connect_data((char *)cp->data,
		sizeof(cp->data));
	send_packet(cp, t);
}


void send_auth_request(atransport *t)
{
	D("Calling send_auth_request\n");
	apacket *p;
	int ret;

	ret = adb_auth_generate_token(t->token, sizeof(t->token));
	if (ret != sizeof(t->token)) {
		D("Error generating token ret=%d\n", ret);
		return;
	}

	p = get_apacket(t);
	memcpy(p->data, t->token, ret);
	p->msg.command = A_AUTH;
	p->msg.arg0 = ADB_AUTH_TOKEN;
	p->msg.data_length = ret;
	send_packet(p, t);
}

void send_auth_response(uint8_t *token, size_t token_size, atransport *t)
{
	D("Calling send_auth_response\n");
	apacket *p = get_apacket(t);
	int ret;

	ret = adb_auth_sign(t->key, token, token_size, p->data);
	if (!ret) {
		D("Error signing the token\n");
		put_apacket(p, t);
		return;
	}

	p->msg.command = A_AUTH;
	p->msg.arg0 = ADB_AUTH_SIGNATURE;
	p->msg.data_length = ret;
	send_packet(p, t);
}

void send_auth_publickey(atransport *t)
{
	D("Calling send_auth_publickey\n");
	apacket *p = get_apacket(t);
	int ret;

	ret = adb_auth_get_userkey(p->data, sizeof(p->data));
	if (!ret) {
		D("Failed to get user public key\n");
		put_apacket(p, t);
		return;
	}

	p->msg.command = A_AUTH;
	p->msg.arg0 = ADB_AUTH_RSAPUBLICKEY;
	p->msg.data_length = ret;
	send_packet(p, t);
}

void adb_auth_verified(atransport *t)
{
	handle_online(t);
	send_connect(t);
}

char *connection_state_name(atransport *t)
{
	if (t == NULL) {
		return "unknown";
	}

	switch (t->connection_state) {
	case CS_BOOTLOADER:
		return "bootloader";
	case CS_DEVICE:
		return "device";
	case CS_OFFLINE:
		return "offline";
	default:
		return "unknown";
	}
}

/* qual_overwrite is used to overwrite a qualifier string.  dst is a
* pointer to a char pointer.  It is assumed that if *dst is non-NULL, it
* was malloc'ed and needs to freed.  *dst will be set to a dup of src.
*/
void qual_overwrite(char **dst, const char *src)
{
	if (!dst)
		return;

	free(*dst);
	*dst = NULL;

	if (!src || !*src)
		return;

	*dst = strdup(src);
}


char *adb_strtok_r(char *s, const char *delim, char **last)
{
	char *spanp;
	int c, sc;
	char *tok;


	if (s == NULL && (s = *last) == NULL)
		return (NULL);

	/*
	* Skip (span) leading delimiters (s += strspn(s, delim), sort of).
	*/
cont:
	c = *s++;
	for (spanp = (char *)delim; (sc = *spanp++) != 0;) {
		if (c == sc)
			goto cont;
	}

	if (c == 0) {		/* no non-delimiter characters */
		*last = NULL;
		return (NULL);
	}
	tok = s - 1;

	/*
	* Scan token (scan for delimiters: s += strcspn(s, delim), sort of).
	* Note that delim must have one NUL; we stop if we see that, too.
	*/
	for (;;) {
		c = *s++;
		spanp = (char *)delim;
		do {
			if ((sc = *spanp++) == c) {
				if (c == 0)
					s = NULL;
				else
					s[-1] = 0;
				*last = s;
				return (tok);
			}
		} while (sc != 0);
	}
	/* NOTREACHED */
}


void parse_banner(char *banner, atransport *t)
{
	static const char *prop_seps = ";";
	static const char key_val_sep = '=';
	char *cp;
	char *type;

	D("parse_banner: %s\n", banner);
	type = banner;
	cp = strchr(type, ':');
	if (cp) {
		*cp++ = 0;
		/* Nothing is done with second field. */
		cp = strchr(cp, ':');
		if (cp) {
			char *save;
			char *key;
			key = adb_strtok_r(cp + 1, prop_seps, &save);
			while (key) {
				cp = strchr(key, key_val_sep);
				if (cp) {
					*cp++ = '\0';
					if (!strcmp(key, "ro.product.name"))
						qual_overwrite(&t->product, cp);
					else if (!strcmp(key, "ro.product.model"))
						qual_overwrite(&t->model, cp);
					else if (!strcmp(key, "ro.product.device"))
						qual_overwrite(&t->device, cp);
				}
				key = adb_strtok_r(NULL, prop_seps, &save);
			}
		}
	}

	if (!strcmp(type, "bootloader")){
		D("setting connection_state to CS_BOOTLOADER\n");
		t->connection_state = CS_BOOTLOADER;
		//update_transports();
		return;
	}

	if (!strcmp(type, "device")) {
		D("setting connection_state to CS_DEVICE\n");
		t->connection_state = CS_DEVICE;
		//update_transports();
		return;
	}

	if (!strcmp(type, "recovery")) {
		D("setting connection_state to CS_RECOVERY\n");
		t->connection_state = CS_RECOVERY;
		//update_transports();
		return;
	}

	if (!strcmp(type, "sideload")) {
		D("setting connection_state to CS_SIDELOAD\n");
		t->connection_state = CS_SIDELOAD;
		//update_transports();
		return;
	}

	t->connection_state = CS_HOST;
}


void handle_packet(apacket* &p, atransport *t)
{
	//asocket *s;
	//D("handle_packet() %c%c%c%c\n", ((char*)(&(p->msg.command)))[0],
	//	((char*)(&(p->msg.command)))[1],
	//	((char*)(&(p->msg.command)))[2],
	//	((char*)(&(p->msg.command)))[3]);

	print_packet("handle_packet():", p);

	switch (p->msg.command){
	case A_SYNC:
		if (p->msg.arg0){
			send_packet(p, t);
			//if (HOST) 
			send_connect(t);
		}
		else {
			t->connection_state = CS_OFFLINE;
			handle_offline(t);
			send_packet(p, t);
		}
		return;

	case A_CNXN: /* CONNECT(version, maxdata, "system-id-string") */
		/* XXX verify version, etc */
		if (t->connection_state != CS_OFFLINE) {
			t->connection_state = CS_OFFLINE;
			handle_offline(t);
		}

		parse_banner((char*)p->data, t);
		//PC�� HOST = 1 auth_enabled = 0
		//if (HOST || !auth_enabled) {
		if (!t->online){
			handle_online(t);
			//if (!HOST) 
			if (t->connection_state != CS_DEVICE){
				send_connect(t);
			}
		}
		else {//����PC��ע��������Ϊ����������
			//send_auth_request(t);
		}
		break;

	case A_AUTH:
		if (p->msg.arg0 == ADB_AUTH_TOKEN) {
			t->key = adb_auth_nextkey(t->key);
			if (t->key) {
				send_auth_response(p->data, p->msg.data_length, t);
			}
			else {
				/* No more private keys to try, send the public key */
				send_auth_publickey(t);
			}
		}
		else if (p->msg.arg0 == ADB_AUTH_SIGNATURE) {
			if (adb_auth_verify(t->token, p->data, p->msg.data_length)) {
				adb_auth_verified(t);
				t->failed_auth_attempts = 0;
			}
			else {
				if (t->failed_auth_attempts++ > 10)
					adb_sleep_ms(1000);
				send_auth_request(t);
			}
		}
		else if (p->msg.arg0 == ADB_AUTH_RSAPUBLICKEY) {
			adb_auth_confirm_key(p->data, p->msg.data_length, t);
		}
		break;

	case A_OPEN: /* OPEN(local-id, 0, "destination") */  //�����豸ͨѶsocket
		if (t->online) {
			if (bip_user_remove_exist(p->msg.arg1, t)){
				remote_socket_close(p->msg.arg0, p->msg.arg1, t);
			}
			//char *name = (char*)p->data;
			//name[p->msg.data_length > 0 ? p->msg.data_length - 1 : 0] = 0;
			//s = create_local_service_socket(name);
			//if (s == 0) {
			//	send_close(0, p->msg.arg0, t);
			//}
			//else {
			//	s->peer = create_remote_socket(p->msg.arg0, t);
			//	s->peer->peer = s;
			//	send_ready(s->id, s->peer->id, t);
			//	s->ready(s);
			//}
		}
		break;

	case A_OKAY: /* READY(local-id, remote-id, "") */
		if (t->online) {
			if (bip_user_remove_exist(p->msg.arg1, t)){
				remote_socket_close(p->msg.arg0, p->msg.arg1, t);
			}
			BipBuffer bip = (BipBuffer)p->msg.arg1;
			if (bip){
				bip->remote_id = p->msg.arg0;
				if (bip->biptype == bipbuffer_file_sync || bip->biptype == bipbuffer_forward){
					bip->finshed = 1;
				}
				//if (bip->biptype != bipbuffer_file_sync){
				//	local_socket_ready_notify(p->msg.arg0, p->msg.arg1);
				//}
			}
			//if ((s = find_local_socket(p->msg.arg1))) {
			//	if (s->peer == 0) {
			//		s->peer = create_remote_socket(p->msg.arg0, t);
			//		s->peer->peer = s;
			//	}
			//	s->ready(s);
			//}
		}
		break;

	case A_CLSE: /* CLOSE(local-id, remote-id, "") */
		if (t->online) {
			BipBuffer bip = (BipBuffer)p->msg.arg1;
			remote_socket_close(p->msg.arg0, p->msg.arg1, t);
			//ͨ���������
			if (bip){
				bip->biptype = bipbuffer_close;
				bip->remote_id = 0;//�����ѹر�
				bip->finshed = 1;
				bip_user_remove_del((int)bip, t);
			}
			//if ((s = find_local_socket(p->msg.arg1))) {
			//	s->close(s);
			//}
		}
		break;

	case A_WRTE:
		if (t->online) {
			unsigned  rid = p->msg.arg0;
			int		_ibip = p->msg.arg1;
			if (bip_user_remove_exist(p->msg.arg1, t)){
				remote_socket_close(p->msg.arg0, p->msg.arg1, t);
			}
			//p->len = p->msg.data_length;

			if (local_socket_enqueue(p->msg.arg1, p) == 0){//  local_socket_enqueue ֮�� p �Ѿ����� ��������
				//����ǽ�����Ҫ�������
				BipBuffer __p = (BipBuffer)_ibip;
				if (__p){
					__p->remote_id = rid;			//��¼��ǰ����ͨ��
					switch (__p->biptype)
					{
					case bipbuffer_shell_async:{
						__p->finshed = 1;
						break; }
					case bipbuffer_file_sync:{//
						break; }
					default:
						break;
					}
				}
				send_ready(_ibip, rid, t);
			}
			p = NULL;
			return;
			//if ((s = find_local_socket(p->msg.arg1))) {
			//	unsigned rid = p->msg.arg0;
			//	p->len = p->msg.data_length;

			//	if (s->enqueue(s, p) == 0) {
			//		D("Enqueue the socket\n");
			//		send_ready(s->id, rid, t);
			//	}
			//	return;
			//}
		}
		break;

	default:
		printf("handle_packet: what is %08x?!\n", p->msg.command);
	}
	put_apacket(p, t);
}

void *output_thread(void *_t)
{
	atransport *t = (atransport *)_t;
	apacket *p;

	D("%s: starting transport output thread on fd %d, SYNC online (%d)\n",
		t->serial, t->fd, t->sync_token + 1);

	p = get_apacket(t);
	p->msg.command = A_SYNC;
	p->msg.arg0 = 1;
	p->msg.arg1 = ++(t->sync_token);
	p->msg.magic = A_SYNC ^ 0xffffffff;
	if (write_packet(t->fd, t->pair, p)) {
		put_apacket(p, t);
		D("%s: failed to write SYNC packet\n", t->serial);
		goto oops;
	}

	D("%s: data pump started\n", t->serial);
	for (;;) {
		if (!p){ p = get_apacket(t); }
		if (!p){ continue; }
		if (t->read_from_remote(p, t) == 0){
			D("%s: received remote packet, sending to transport\n",
				t->serial);
			print_packet("read_from_remote():", p);
			if (write_packet(t->fd, t->pair, p)){
				put_apacket(p, t);
				D("%s: failed to write apacket to transport\n", t->serial);
				//goto oops;
			}
		}
		else {
			D("%s: remote read failed for transport\n", t->serial);
			put_apacket(p, t);
			break;
		}
	}

	D("%s: SYNC offline for transport\n", t->serial);
	p = get_apacket(t);
	p->msg.command = A_SYNC;
	p->msg.arg0 = 0;
	p->msg.arg1 = 0;
	p->msg.magic = A_SYNC ^ 0xffffffff;
	if (write_packet(t->fd, t->pair, p)) {
		put_apacket(p, t);
		D("%s: failed to write SYNC apacket to transport", t->serial);
	}

oops:
	D("%s: transport output thread is exiting\n", t->serial);
	t->close(t);	//�豸�Ѿ��Ͽ�
	--t->ref_count;
	return 0;
}


void *input_thread(void *_t)
{
	atransport *t = (atransport *)_t;
	apacket *p = NULL;
	int active = 0;

	D("%s: starting transport input thread, reading from fd %d\n",
		t->serial, t->fd);

	for (;;){
		if (read_packet(t->fd, t->pair, p)) {
			D("%s: failed to read apacket from transport on fd %d\n",
				t->serial, t->fd);
			break;
		}
		if (!p){ continue; }
		print_packet("write_to_remote():", p);
		if (p->msg.command == A_SYNC){
			if (p->msg.arg0 == 0) {
				D("%s: transport SYNC offline\n", t->serial);
				put_apacket(p, t);
				break;
			}
			else {
				if (p->msg.arg1 == t->sync_token) {
					D("%s: transport SYNC online\n", t->serial);
					active = 1;
				}
				else {
					D("%s: transport ignoring SYNC %d != %d\n",
						t->serial, p->msg.arg1, t->sync_token);
				}
			}
		}
		else {
			if (active) {
				D("%s: transport got packet, sending to remote\n", t->serial);
				t->write_to_remote(p, t);
			}
			else {
				D("%s: transport ignoring packet while offline\n", t->serial);
			}
		}
		put_apacket(p, t);
	}

	D("%s: transport input thread is exiting, fd %d\n", t->serial, t->fd);
	t->close(t);
	--t->ref_count;
	return 0;
}

void transport_registration_func(atransport *t, int action)
{
	adb_thread_t user_thread_ptr;
	adb_thread_t output_thread_ptr;
	adb_thread_t input_thread_ptr;

	if (action == 0){
		D("transport: %s removing and free'ing %d\n", t->serial, t->transport_socket);
		/* IMPORTANT: the remove closes one half of the
		** socket pair.  The close closes the other half.
		*/
		while (t->ref_count != 0 || t->connectCount != 0)
		{
			adb_close(t->fd, t->pair);
			delay(10);
		}
		t->pair->used = 0;
		adb_close(t->fd, t->pair);

		t->kick(t);	//�޳��豸�б�
		t->close(t);	//�ر�usbͨ��

		if (t->pair){
			delete t->pair;
			t->pair = NULL;
		}
		//if (t->usb){
		//	remote_close(t);
		//}
		if (t->product)
			free(t->product);
		if (t->serial)
			free(t->serial);
		if (t->model)
			free(t->model);
		if (t->device)
			free(t->device);
		if (t->devpath)
			free(t->devpath);

		{
			adb_mutex_lock _lock(t->bip_lock);
			for (BipRecPtrList::iterator it = t->bipUserRemoveList.begin(); it != t->bipUserRemoveList.end(); ++it){
				delete (BipBuffer)*it;
			}
			t->bipUserRemoveList.clear(); 
		}
		apacketlistptr aplistptr = t->loop_to_use_apacket;
		t->loop_to_use_apacket = NULL;
		if (aplistptr){
			apacket* p = NULL;;
			while (aplistptr->pop(p)){
				put_apacket(p, t);
			}
			delete aplistptr;
			aplistptr = NULL;
		}

		//delete t;
		atransport_put(t);
		return;
	}

	/* don't create transport threads for inaccessible devices */
	if (t->connection_state != CS_NOPERM) {
		/* initial references are the two threads */
		t->ref_count = 3;

		t->pair = adb_socketpair();
		if (!t->pair) {
			//fatal_errno("cannot open transport socketpair");
			return;
		}

		D("transport: %s (%d,%d) starting\n", t->serial, t->fd, t->sfd);

		int evID = t->pair->a_fd;
		t->transport_socket = evID;
		t->fd = evID + 1;

		t->loop_to_use_apacket = new apacketlist(0);

		if (adb_thread_create(&input_thread_ptr, input_thread, t)){
			D("cannot create input thread");
			return;
		}

		if (adb_thread_create(&output_thread_ptr, output_thread, t)){
			D("cannot create output thread");
			return;
		}

		if (adb_thread_create(&user_thread_ptr, user_thread, t)){
			D("cannot create input thread");
			return;
		}
	}
}

void *user_thread(void *_t)	///�û��������
{
	atransport *t = (atransport *)_t;
	apacket *p = NULL;
	int __online = 1;

	while (__online)
	{
		p = NULL;
		if (read_packet(t->transport_socket, t->pair, p)){
			D("%s: failed to read packet from transport socket on fd \n", t->serial);
			break;
		}
		else if (!p){
			//�հ�
		}else {
			D("%s: read packet from transport socket on addr : %d\n", t->serial, (int)p);
			if (p->msg.command == A_SYNC){//�ж��˳�
				if (p->msg.arg0 == 0) {
					D("%s: transport SYNC offline\n", t->serial);
					__online = 0;	//�Ѱ�����ȥ�� ���˳�
				}
			}
			handle_packet(p, (atransport *)_t);
		}
		//adb_sleep_ms(5);
	}
	t->close(t);
	--t->ref_count;
	return 0;
}

void bip_user_remove_add(int _bip, atransport* t){		//����ͨ��ɾ������
	if (t){
		adb_mutex_lock _lock(t->bip_lock);
		t->bipUserRemoveList.insert(_bip);
	}
}

void bip_user_remove_del(int _bip, atransport* t){		//ɾ��������ָ��ͨ��
	if (_bip && t){
		adb_mutex_lock _lock(t->bip_lock);
		BipRecPtrList::iterator it = t->bipUserRemoveList.find(_bip);
		if (it != t->bipUserRemoveList.end())//���� ɾ���б����� ͬʱ��ͨ��ɾ��
		{
			BipBuffer bip = (BipBuffer)_bip;
			bip->closed = 1;
			BipLpList biplist = bip->ptrlist;
			bip->ptrlist = NULL;
			apacket* p = NULL;
			if (biplist){
				while (biplist->pop(p)){
					delete p;
				}
			}
			delete biplist;
			p = (apacket*)bip->last_apacket;
			bip->last_apacket = NULL;
			put_apacket(p);
			delete bip;
			t->bipUserRemoveList.erase(it);
		}
	}
}

int  bip_user_remove_exist(int _bip, atransport* t){	//ɾ�������Ƿ����ָ��ͨ�� ��0 ��ʾ����
	if (t){
		adb_mutex_lock _lock(t->bip_lock);
		if ((t->bipUserRemoveList.find(_bip) != t->bipUserRemoveList.end())){
			return 1;
		}
	}
	return 0;
}

int remote_socket_enqueue(BipBuffer userbip, atransport* t, apacket *p)
{
	D("entered remote_socket_enqueue WRITE fd=%d peer.fd=%d\n",
		(int)userbip, t->fd);
	p->msg.command = A_WRTE;
	p->msg.arg0 = (int)userbip;
	p->msg.arg1 = userbip->remote_id;
	p->msg.data_length = p->len;
	send_packet(p, t);
	return 1;
}

void remote_socket_ready(BipBuffer userbip, atransport* t)
{
	D("entered remote_socket_ready OKAY fd=%d peer.fd=%d\n",
		(int)userbip, t->fd);
	apacket *p = get_apacket(t);
	p->msg.command = A_OKAY;
	p->msg.arg0 = (int)userbip;
	p->msg.arg1 = userbip->remote_id;
	send_packet(p, t);
}

void remote_socket_close(int remote_arg0, int bip_arg1, atransport* t)
{
	if (t) {
		D("entered remote_socket_close CLOSE remoteID=%08x bip=%08x\n",
			remote_arg0, bip_arg1);
		apacket *p = get_apacket(t);
		p->msg.command = A_CLSE;
		p->msg.arg0 = bip_arg1;//0;
		p->msg.arg1 = remote_arg0;
		send_packet(p, t);
		//D("RS(%d): closed\n", t->fd);
	}
}

void connect_to_remote(BipBuffer userbip, atransport* t, const char *destination)
{
	D("Connect_to_remote call RS(%d) fd=%d\n", t->fd, (int)userbip);
	apacket *p = get_apacket(t);
	int len = strlen(destination) + 1;

	if (userbip->closed){
		return;
	}

	if (len > (MAX_PAYLOAD - 1)) {
		D("destination oversized\n");
	}

	D("LS(%d): connect('%s')\n", t->fd, destination);
	p->msg.command = A_OPEN;
	p->msg.arg0 = (int)userbip;
	p->msg.data_length = len;
	strcpy((char*)p->data, destination);
	send_packet(p, t);
}

void remote_socket_offline(atransport* t){
	apacket* p = get_apacket(t);
	if (p){
		p->msg.command = A_SYNC;
		p->msg.arg0 = 0;
		p->msg.arg1 = 0;
		p->msg.magic = A_SYNC ^ 0xffffffff;
		send_packet(p, t);
	}
}

int smart_socket_enqueue(BipBuffer userbip, atransport* t, apacket *p)
{
	unsigned len;

	char *service = NULL;
	char* serial = NULL;
	transport_type ttype = kTransportAny;

	int userPtr = (int)userbip;

	if (t->connection_state != CS_DEVICE){//�豸��δ����
		local_socket_faile_notify("now did't connect to device", userPtr);
		return -1;
	}

	D("SS(%d): enqueue %d\n", userPtr, p->len);
	print_packet("smart_socket_enqueue", p);

	/* don't bother if we can't decode the length */
	if (p->len < 4) return 0;

	len = p->len;
	if ((len < 1) || (len > 1024)) {
		D("SS(%d): bad size (%d)\n", userPtr, len);
		goto fail;
	}
	if (len > MAX_PAYLOAD){
		D("SS(%d): overflow\n", userPtr);
		put_apacket(p, t);
		goto fail;
	}
	D("SS(%d): len is %d\n", userPtr, len);


	//D("SS(%d): '%s'\n", s->id, (char*)(p->data + 4));

	service = (char *)p->data;
	if (!strncmp(service, "host-serial:", strlen("host-serial:"))) {
		service += strlen("host-serial:");
	}
	else if (!strncmp(service, "host-usb:", strlen("host-usb:"))) {
		ttype = kTransportUsb;
		service += strlen("host-usb:");
	}
	else if (!strncmp(service, "host-local:", strlen("host-local:"))) {
		ttype = kTransportLocal;
		service += strlen("host-local:");
	}
	else if (!strncmp(service, "host:", strlen("host:"))) {
		ttype = kTransportAny;
		service += strlen("host:");
	}
	else {
		service = NULL;
	}

	if (service) {
		//��������� �豸 ��ָ�� ������ȥ���ӣ����ﱾ�����Ѿ�������
		local_socket_ready_notify(0, userPtr);
		userbip->finshed = 1;
		return 1;
	}

	connect_to_remote(userbip, t, (char*)(p->data));
	put_apacket(p);
	return 1;

fail:

	return -1;
}

void adb_set_bipbuffer_type(int _type, BipBuffer userbip, atransport* t){
	int _utype = userbip->biptype;
	if (_type < 0){
		return;
	}
	else if (_utype == bipbuffer_close){
		//�ر�״̬ ��ֱ�Ӹ�ֵ
	}
	else if (_utype != _type){
		while (userbip->remote_id == 0 && (userbip->biptype != bipbuffer_close)){//�Ѿ����͹���Ϣ��ȥ ��ôҪ�ȴ���Ϣ����
			adb_sleep_ms(10);
		}
		if (userbip->remote_id > 0){
			remote_socket_close(userbip->remote_id, (int)userbip, t);
		}
		while (userbip->biptype != bipbuffer_close){
			adb_sleep_ms(10);
		}
	}
	userbip->finshed = 0;	//���´��ڴ����
	userbip->biptype = _type;
}

int adb_shell_send(BipBuffer userbip, atransport* t, const char *destination, int len){
	int shellhead = 0;
	int _utype = -1;

	if (!userbip || !t ){ return -1; }

	if (t->connection_state != CS_DEVICE){//�豸��δ����
		local_socket_faile_notify("now did't connect to device", (int)userbip);
		return -1;
	}

	if (!strncmp(destination, "shell:", strlen("shell:"))) {//��shell ��ͷ �ж���ͬ�� ���ǽ���
		_utype = bipbuffer_shell_sync;
		shellhead = 1;
	}
	if (!strncmp(destination, "shell:", len)) {//��shell ��ͷ �ж���ͬ�� ���ǽ���
		_utype = bipbuffer_shell_async;
		shellhead = 1;
	}
	//��������ô���� ����
	if (_utype > -1){
		adb_set_bipbuffer_type(_utype, userbip, t);//�ر���ǰ���ܴ򿪵�����ͨ��
	}
	
	apacket *p = get_apacket(t);
	if (p && (len < MAX_PAYLOAD)){
		if (shellhead)
		{
			p->len = len;
			sprintf((char*)p->data, "%s", destination);
			return smart_socket_enqueue(userbip, t, p);
		}
		else
		{
			if (userbip->biptype != bipbuffer_shell_async){//���ǽ���ģʽ�� ��ִ��
				local_socket_faile_notify("not run shell:\n", (int)userbip);
				return -1;
			}
			char* ch = (char*)p->data;
			sprintf(ch, "%s\n", destination);
			p->len = strlen(ch);
			return remote_socket_enqueue(userbip, t, p);
		}
	}else{
		put_apacket(p, t);
	}
	return -1;
}

int adb_shell_recv(BipBuffer userbip, atransport* t, sstring &ret, int wait_times /*= 0*/){
	void *_dst = NULL;
	BipBuffer bip = userbip;
	int succ = 0, _typebip = 0;
	time_t maxtime = time(NULL) + wait_times;
	char endchar = '0';

	do{
		if (!bip->ptrlist){ return -1; }
		_typebip = bip->biptype;
		if (bip->ptrlist->pop(_dst)){//�ǿ������ ��ȡ ����
			maxtime = time(NULL) + wait_times;//ʱ������
			apacket* ap = (apacket*)_dst;
			_dst = NULL;
			if (ap){
				ret.append((char*)ap->data, ap->msg.data_length);
				put_apacket(ap, t);
				if (_typebip == bipbuffer_shell_async){
					if (ret.length() > 2){
						endchar = (*(ret.end() - 2));	//���һ���ַ�
					}
				}
			}
		}else if (bip->closed || t->kicked){//�ر����˳�
			succ = 1;
		}
		else if (bip->finshed)//û�������� �������״̬���˳� 
		{
			//����һ�� ����ǽ���ʽ ��ô
			if (_typebip == bipbuffer_shell_async){
				if (endchar == '#' || endchar == '$'){ 	//���һ���ַ� �Ƿ��� # ���� $
					succ = 1;
				}
			}
			else{
				succ = 1;
			}
		}
		if (wait_times){
			if (maxtime < time(NULL)){ succ = 1; }//��ʱ
		}
	} while (!succ);
	bip->finshed = 0; //��ԭ
	D("adb_shell_recv exit\n");
	return 0;
}

void local_socket_faile_notify(const char* msgstr, int bip){
	D("local_socket_faile_notify()<BipBuff:%d>:%s\n", bip, msgstr);
	if (bip){
		BipBuffer _bip = (BipBuffer)bip;
		if (_bip->closed){
			return;
		}
		apacket	*p = get_apacket();
		if (p){
			int len = strlen(msgstr) + 6;
			char* errstr = new char[len]();
			sprintf_s(errstr, len, "FAIL:%s", msgstr);
			memcpy(p->data, errstr, len);
			p->msg.data_length = len;
			void* temp = p;
			p = NULL;
			bip_buffer_write(_bip, temp);
			_bip->finshed = 1;
			delete[] errstr;
		}
		else{
			put_apacket(p);
		}
	}
}

void local_socket_ready_notify(int remote, int bip)
{
	D("local_socket_ready_notify()<BipBuff>:%d\n", bip);
	if (bip){
		BipBuffer _bip = (BipBuffer)bip;
		if (_bip->closed){
			return;
		}
		apacket	*p = get_apacket();
		if (p){
			_bip->remote_id = remote;	//��¼���ӵ����豸ͨ��ID
			memcpy(p->data, "OKAY\0", 5);
			p->msg.data_length = 4;
			void* temp = p;
			p = NULL;
			bip_buffer_write(_bip, temp);
		}else{
			put_apacket(p);
		}
	}
}

int local_socket_enqueue(int bip_arg1, apacket *p){
	int ret = -1;
	if (bip_arg1)
	{
		BipBuffer bip = (BipBuffer)bip_arg1;
		if (bip->closed){
			put_apacket(p);
			return -1;
		}
		void* temp = p;
		p = NULL;
		ret = bip_buffer_write(bip, temp);
		if (ret){
			apacket* ap = (apacket*)temp;
			temp = NULL;
			put_apacket(ap);
		}
	}
	return ret;
}

void local_socket_close(BipBuffer userbip, atransport* t){
	if (userbip){
		bip_user_remove_add((int)userbip, t);
		if (userbip->remote_id != 0){
			remote_socket_close(userbip->remote_id, (int)userbip, t);
		}
		bip_buffer_close(userbip);
	}
}

//forward
int adb_forward_connect(const char* remote_connect, BipBuffer userbip, atransport* t){
	if (!userbip || !t || (*remote_connect == 0)){ return -1; }

	if (t->connection_state != CS_DEVICE){//�豸��δ����
		local_socket_faile_notify("now did't connect to device", (int)userbip);
		return -1;
	}

	adb_set_bipbuffer_type(bipbuffer_forward, userbip, t);//�ر���ǰ���ܴ򿪵�����ͨ��

	apacket* p = (apacket*)userbip->last_apacket;
	userbip->last_apacket = NULL;
	if (p){ put_apacket(p, t); }

	connect_to_remote(userbip, t, remote_connect);
	while (!userbip->finshed){ //�ȴ����ӷ���
		adb_sleep_ms(5);
		if (userbip->biptype == bipbuffer_close || t->kicked){ return -1; }
	}
	return 1;
}

int adb_forward_write(void* sendData, int len, BipBuffer userbip, atransport* t){	//��������
	if (!userbip || !t){ return -1; }

	if (userbip->biptype != bipbuffer_forward){
		local_socket_faile_notify("now did't connect to forward", (int)userbip);
		return -1;
	}
	int rlen = len, slen = 0;
	unsigned char* ptr = (unsigned char*)sendData;

	while (rlen > 0)
	{
		if (userbip->closed){ return -1; }
		slen = ((rlen > MAX_PAYLOAD) ? MAX_PAYLOAD : rlen);
		apacket* p = get_apacket(t);
		p->len = slen;
		memcpy(p->data, ptr, slen);
		remote_socket_enqueue(userbip, t, p);
		ptr += slen;
		rlen -= slen;
	}
	return 1;
}

//����һ�����ȣ� β����η������һ������ָ�뱣��δ��������� ��ȴ�ʱ��(��)
int adb_forward_read(unsigned char* retData, int len, BipBuffer userbip, atransport* t, int wait_times /*= 0*/){
	if (!userbip){ return -1; }

	if (userbip->biptype != bipbuffer_forward){
		retData = (unsigned char*)strupr("now did't connect to forward");
		return strlen((char*)retData);
	}
	apacket* retLastApacket = (apacket*)userbip->last_apacket;
	//ÿ�ζ�ȡ����һ���������� ֱ���������ݳ���
	int length = 0;
	if (userbip->ptrlist){
		int readlen = len, clen = 0;
		time_t maxtimes = time(NULL) + wait_times;
		unsigned char* _des = retData;	//��ַ����
		adb_sleep_ms(10);//�ӳ� �ȴ����ݷ���
		//��ʼ��ȡ����
		if (retLastApacket){
			if (retLastApacket->ptr == NULL){ 
				retLastApacket->ptr = retLastApacket->data; 
				retLastApacket->len = retLastApacket->msg.data_length;
			}
		}
		while (readlen > 0 && (!userbip->closed || t->kicked))
		{
			if (retLastApacket){
				if (retLastApacket->len == 0){
					put_apacket(retLastApacket, t);
					retLastApacket = NULL;
					userbip->last_apacket = NULL;
				}
				else
				{
					clen = (readlen > retLastApacket->len) ? retLastApacket->len : readlen;
					memcpy(_des, retLastApacket->ptr, clen);
					readlen -= clen;
					_des += clen;
					retLastApacket->ptr += clen;
					retLastApacket->len -= clen;
					length += clen;
				}
				maxtimes = time(NULL) + wait_times;
			}
			else
			{
				if (!userbip->ptrlist){ return -1; }
				if (userbip->ptrlist->pop(retLastApacket)){
					if (retLastApacket){
						userbip->last_apacket = retLastApacket;//�������µİ�
						retLastApacket->ptr = retLastApacket->data;
						retLastApacket->len = retLastApacket->msg.data_length;
					}
					maxtimes = time(NULL) + wait_times;
				}
			}
			if (wait_times){
				if (maxtimes < time(NULL)){
					break;
				}
			}
		}
	}
	return length;
}

int adb_forward_disconnect(BipBuffer userbip, atransport* t){
	int ubid = (int)userbip;

	if (!userbip|| !t){ return -1; }

	if (t->connection_state != CS_DEVICE){//�豸��δ����
		local_socket_faile_notify("now did't connect to device", ubid);
		return 0;
	}
	
	if (userbip->remote_id == 0){
		local_socket_faile_notify("the forward had disconnect", ubid);
		return 0;
	}
	remote_socket_close(userbip->remote_id, ubid, t);
	while (userbip->biptype != bipbuffer_close && !userbip->closed){//�ȴ�ͨ���ر����
		adb_sleep_ms(50);
	}
	apacket* p = (apacket*)userbip->last_apacket;
	userbip->last_apacket = NULL;
	if (p){ put_apacket(p, t); }
	return 1;
}

//sync �ļ�����
int adb_sync_connect(BipBuffer userbip, atransport* t){
	char* remote_connect = "sync:";
	int len = strlen(remote_connect);

	if (!userbip || !t ){ return -1; }

	if (t->connection_state != CS_DEVICE){//�豸��δ����
		local_socket_faile_notify("now did't connect to device", (int)userbip);
		return -1;
	}

	adb_set_bipbuffer_type(bipbuffer_file_sync, userbip, t);//�ر���ǰ���ܴ򿪵�����ͨ��

	apacket* p = (apacket*)userbip->last_apacket;
	userbip->last_apacket = NULL;
	if (p){ put_apacket(p, t); }

	connect_to_remote(userbip, t, remote_connect);
	while (!userbip->finshed){ //�ȴ����ӷ���
		adb_sleep_ms(5); 
		if (userbip->biptype == bipbuffer_close || t->kicked){ return -1; }
	}
	return 1;
}

int adb_sync_write(void* sendData, int len, BipBuffer userbip, atransport* t){
	if (!userbip || !t){ return -1; }

	if (userbip->biptype != bipbuffer_file_sync){
		local_socket_faile_notify("now did't connect to sync:", (int)userbip);
		return -1;
	}
	//bool issend = false;
	int rlen = len, slen = 0;
	unsigned char* ptr = (unsigned char*)sendData;

	userbip->finshed = 0;

	while (rlen > 0)
	{
		if (userbip->closed){ return -1; }
		slen = ((rlen > MAX_PAYLOAD) ? MAX_PAYLOAD : rlen);
		apacket* p = get_apacket(t);
		p->len = slen;
		memcpy(p->data, ptr, slen);
		remote_socket_enqueue(userbip, t, p);
		//issend = true;
		ptr += slen;
		rlen -= slen;
	}
	//while (issend && userbip->finshed != 1){
	//	adb_sleep_ms(5);
	//}
	return 1;
}

int adb_sync_read(unsigned char* retData, int len, BipBuffer userbip, atransport* t, int wait_times/* = 0*/){	//����һ�����ȣ� β����η������һ������ָ�뱣��δ��������� ��ȴ�ʱ��(��)
	if (!userbip){ return -1; }

	if (userbip->biptype != bipbuffer_file_sync){
		local_socket_faile_notify("now did't connect to sync:", (int)userbip);
		return -1;
	}
	apacket* retLastApacket = (apacket*)userbip->last_apacket;
	//ÿ�ζ�ȡ����һ���������� ֱ���������ݳ���
	int length = 0;
	if (userbip->ptrlist){
		int readlen = len, clen = 0;
		time_t maxtimes = time(NULL) + wait_times;
		unsigned char* _des = retData;	//��ַ����
		adb_sleep_ms(10);//�ӳ� �ȴ����ݷ���
		//��ʼ��ȡ����
		if (retLastApacket){
			if (retLastApacket->ptr == NULL){
				retLastApacket->ptr = retLastApacket->data;
				retLastApacket->len = retLastApacket->msg.data_length;
			}
		}
		while (readlen > 0 && (!userbip->closed || t->kicked))
		{
			if (retLastApacket){
				if (retLastApacket->len == 0){
					put_apacket(retLastApacket, t);
					retLastApacket = NULL;
					userbip->last_apacket = NULL;
				}
				else
				{
					clen = (readlen > retLastApacket->len) ? retLastApacket->len : readlen;
					memcpy(_des, retLastApacket->ptr, clen);
					readlen -= clen;
					_des += clen;
					retLastApacket->ptr += clen;
					retLastApacket->len -= clen;
					length += clen;
				}
				maxtimes = time(NULL) + wait_times;
			}
			else
			{
				if (!userbip->ptrlist){ return -1; }
				if (userbip->ptrlist->pop(retLastApacket)){
					if (retLastApacket){
						userbip->last_apacket = retLastApacket;	//�����ȡ�������°�
						retLastApacket->ptr = retLastApacket->data;
						retLastApacket->len = retLastApacket->msg.data_length;
					}
					maxtimes = time(NULL) + wait_times;
				}
			}
			if (wait_times){
				if (maxtimes < time(NULL)){
					break;
				}
			}
		}
	}
	return length;
}

int adb_sync_read_to_buffer(bufferstream &buffer, int len, BipBuffer userbip, atransport* t, int wait_times /*= 0*/){	//����һ�����ȣ� β����η������һ������ָ�뱣��δ��������� ��ȴ�ʱ��(��)
	if (!userbip){ return -1; }

	if (userbip->biptype != bipbuffer_file_sync){
		local_socket_faile_notify("now did't connect to sync:", (int)userbip);
		return -1;
	}
	apacket* retLastApacket = (apacket*)userbip->last_apacket;
	//ÿ�ζ�ȡ����һ���������� ֱ���������ݳ���
	int length = 0;
	if (userbip->ptrlist){
		int readlen = len, clen = 0;
		time_t maxtimes = time(NULL) + wait_times;
		adb_sleep_ms(10);//�ӳ� �ȴ����ݷ���
		//��ʼ��ȡ����
		if (retLastApacket){
			if (retLastApacket->ptr == NULL){
				retLastApacket->ptr = retLastApacket->data;
				retLastApacket->len = retLastApacket->msg.data_length;
			}
		}
		while (readlen > 0 && (!userbip->closed))
		{
			if (retLastApacket){
				if (retLastApacket->len == 0){
					put_apacket(retLastApacket, t);
					retLastApacket = NULL;
					userbip->last_apacket = NULL;
				}
				else
				{
					clen = (readlen > retLastApacket->len) ? retLastApacket->len : readlen;
					buffer.insert(buffer.end(), retLastApacket->ptr, retLastApacket->ptr + clen);
					readlen -= clen;
					retLastApacket->ptr += clen;
					retLastApacket->len -= clen;
					length += clen;
				}
				maxtimes = time(NULL) + wait_times;
			}
			else
			{
				if (!userbip->ptrlist){ return -1; }
				if (userbip->ptrlist->pop(retLastApacket)){
					if (retLastApacket){
						userbip->last_apacket = retLastApacket;	//�����ȡ�������°�
						retLastApacket->ptr = retLastApacket->data;
						retLastApacket->len = retLastApacket->msg.data_length;
					}
					maxtimes = time(NULL) + wait_times;
				}
			}
			if (wait_times){
				if (maxtimes < time(NULL)){
					break;
				}
			}
		}
	}
	return length;
}

int adb_sync_disconnect(BipBuffer userbip, atransport* t){
	int ubid = (int)userbip;

	if (!userbip || !t){ return -1; }

	if (t->connection_state != CS_DEVICE){//�豸��δ����
		local_socket_faile_notify("now did't connect to device", ubid);
		return 0;
	}

	if (userbip->remote_id == 0){
		local_socket_faile_notify("the sync: had disconnect", ubid);
		return 0;
	}
	remote_socket_close(userbip->remote_id, ubid, t);
	while (userbip->biptype != bipbuffer_close && !userbip->closed){//�ȴ�ͨ���ر����
		adb_sleep_ms(50);
	}
	apacket* p = (apacket*)userbip->last_apacket;
	userbip->last_apacket = NULL;
	if (p){ put_apacket(p, t); }
	return 1;
}

int adb_sync_push(const char* lpath, const char* rpath, BipBuffer userbip, atransport* t){
	return do_sync_push(lpath, rpath, 0, userbip, t);
}
int adb_sync_push_buffer(void* buffer, size_t len, const char* rpath, BipBuffer userbip, atransport* t){
	return do_sync_push_buffer((unsigned char*)buffer, len, rpath, userbip, t);
}
int adb_sync_pull(const char* rpath, const char* lpath, BipBuffer userbip, atransport* t){
	return do_sync_pull(rpath, lpath, userbip, t);
}
int adb_sync_pull_buffer(bufferstream &buffer, size_t &len, const char* rpath, BipBuffer userbip, atransport* t){
	return do_sync_pull_buffer(buffer, len, rpath, userbip, t);
}
