#ifndef _CADB_H_
#define _CADB_H_

#include <string>
#include <vector>

typedef	std::string					sstring;
typedef std::vector<unsigned char>	bufferstream;

class CAdb
{
public:
	CAdb(const char* _name_serial);
	CAdb(CAdb& parent);	//�����Ӽ�
	~CAdb();
	static void InitAdb();
	static void FindDevices();
	static void GetDevicesNameList(sstring& ret);
	bool IsOk();
	bool IsUsbClose();
	void UsbClose();
	bool IsClose();
	void Close();
	bool IsOnline();
public:
	sstring get_serial();
public:
	bool Shell_send(const char* data);
	void Shell_recv(sstring& ret, int wait_time = 0);
public:
	int  forwardconnect(const char* data);
	int  forwardwrite(unsigned char* data, int len);
	int  forwardread(unsigned char* data, int len, int wait_times = 0);
	int  forwarddisconnect();
	//void forwardTest();
public:
	bool  sync_push(const char* lpath, const char* rpath);
	bool  sync_pull(const char* rpath, const char* lpath);
	bool  sync_push_buffer(unsigned char* buffer, size_t len, const char* rpath);
	bool  sync_pull_buffer(bufferstream &buffer, size_t &len, const char* rpath);	//return is the recv length
public:
	void*		retBuff;		//�����豸ͨ��ͨ�� ���շ�����Ϣ
	void*		m_atransport;
	bool		isok;
private:
	sstring		name_serial;
};

#endif	//_CADB_H_