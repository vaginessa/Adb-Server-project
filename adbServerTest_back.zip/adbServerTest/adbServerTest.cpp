// adbServerTest.cpp : �������̨Ӧ�ó������ڵ㡣
//

#include "stdafx.h"
#include <iostream>
#include <fstream>
#include "CAdb.h"

int _tmain(int argc, _TCHAR* argv[])
{
	sstring retlist;

	CAdb::InitAdb();
	//while (true)
	//{
		retlist.clear();
		CAdb::FindDevices();
		CAdb::GetDevicesNameList(retlist);
		printf("find device:\n %s \n", retlist.c_str());
	//	system("pause");
	//}
	
	int ret = retlist.find_first_of("|");
	CAdb* temp = NULL;
	if (ret > 0){
		sstring name = retlist.substr(0, ret);
		if (!name.empty())
		{
			printf("Init device:\n %s \n", name.c_str());
			temp = new CAdb(name.c_str());
		}
		else
		{
			return 0;
		}
	}
	else
	{
		return 0;
	}
	//while (true)
	//{
	//	sstring sendstr, retstr;
	//	std::getline(std::cin, sendstr);
	//	//temp->Shell_send(sendstr.c_str());
	//	temp->Shell_send("shell:dumpsys window policy|grep -e mOverscanScreen -e mScreenOnFully -e mShowingLockscreen -e mFocusedWindow -e mCurrentRotation");
	//	temp->Shell_recv(retstr);
	//	printf(retstr.c_str());
	//	printf("\n");
	//}
	//sstring sendstr;
	//std::getline(std::cin, sendstr);

	while (!temp->IsOnline()){
		
	}
	if (temp->Shell_send("shell:")){
		sstring rets;
		temp->Shell_recv(rets);
		//dumpsys window policy|grep -e mOverscanScreen -e mScreenOnFully -e mShowingLockscreen -e mFocusedWindow -e mCurrentRotation
		while (temp->Shell_send("dumpsys window policy|grep -e mOverscanScreen -e mScreenOnFully -e mShowingLockscreen -e mFocusedWindow -e mCurrentRotation"))
		{
			sstring sendstr, retstr;
			
			//std::getline(std::cin, sendstr);
			//temp->Shell_send(sendstr.c_str());
			temp->Shell_recv(retstr);
			printf(retstr.c_str());
			printf("\n");
		}
		temp->Shell_send("exit");
	}

	if (temp){ delete temp; }
	temp = NULL;
	return 0;
}


