#ifndef _ADB_FUNC_H_
#define _ADB_FUNC_H_

#include "adb_struct.h"			//��������
#include "usb_vendors.h"
#include "adb_auth.h"

//��־���
void show_log(const char* _Format, ...);
void show_apacket(const char* label, apacket* p);

//adb_mutex_lock _slock(log_lock);
#define D(fmt, ...)				show_log(fmt, ##__VA_ARGS__)
#define print_packet(label, p)	show_apacket(label, p)

bool atransport_is_free(atransport* t);
void atransport_put(atransport* t);
void atransport_free();

/**************************************************************************/
/*****    USB API				                                      *****/
/**************************************************************************/
typedef	std::map<sstring, atransport*>	devicesMap;

extern	adb_buff_mutex					atransport_lock;
extern	devicesMap						devices_list;	//��ע����豸�б�

/// Checks if there is opened usb handle in handle_list for this device.
int known_device(const char* dev_name);

/// Checks if there is opened usb handle in handle_list for this device.
/// usb_lock mutex must be held before calling this routine.
int known_device_locked(const char* dev_name);

/// Registers opened usb handle (adds it to handle_list).
int register_new_device(usb_handle* handle);

/// Checks if interface (device) matches certain criteria
int recognized_device(usb_handle* handle);

/// Entry point for thread that polls (every second) for new usb interfaces.
/// This routine calls find_devices in infinite loop.
void* device_poll_thread(void* unused);

/// Initializes this module
void usb_init();

/// Cleans up this module
void usb_cleanup();

/// Opens usb interface (device) by interface (device) name.
usb_handle* do_usb_open(const wchar_t* interface_name);

/// Writes data to the opened usb handle
int usb_write(usb_handle* handle, const void* data, int len);

/// Reads data using the opened usb handle
int usb_read(usb_handle *handle, void* data, int len);

/// Cleans up opened usb handle
void usb_cleanup_handle(usb_handle* handle);

/// Cleans up (but don't close) opened usb handle
void usb_kick(usb_handle* handle);

/// Closes opened usb handle
int usb_close(usb_handle* handle);

/// Gets interface (device) name for an opened usb handle
const char *usb_name(usb_handle* handle);

int is_adb_interface(int vid, int pid, int usb_class, int usb_subclass, int usb_protocol);

unsigned host_to_le32(unsigned n);

int remote_read(apacket* p, atransport *t);

int remote_write(apacket* p, atransport *t);

void remote_close(atransport *t);

void remote_kick(atransport *t);

//�û����� ���
int remote_read_user(apacket* &p, atransport *t);
int remote_write_user(apacket* &p, atransport *t);

void init_usb_transport(atransport *t, usb_handle *h, int state);

void register_usb_transport(usb_handle *usb, const char *serial, const char *devpath, unsigned writeable);

/// Enumerates present and available interfaces (devices), opens new ones and
/// registers usb transport for them.
void find_devices();

atransport* get_device(const char* name_serial);

void get_device_name_list(sstring& retlist);

/**************************************************************************/
/*****    ͨѶ API				                                      *****/
/**************************************************************************/

void	bip_buffer_init(BipBuffer  buffer);
void	bip_buffer_close(BipBuffer  bip);
void	bip_buffer_done(BipBuffer  bip);
int		bip_buffer_write(BipBuffer  bip, void* & _scr);
int		bip_buffer_read(BipBuffer  bip, void*& _dst);

SocketPair  adb_socketpair();
int	_fh_socketpair_close(int f, SocketPair  _pair);
int	_fh_socketpair_lseek(int  f, int pos, int  origin);
int	_fh_socketpair_read(int f, SocketPair  _pair, void*& _dst);
int	_fh_socketpair_write(int f, SocketPair  _pair, void*& _scr);
int  adb_read(int f, SocketPair  _pair, void*& _dst);
int  adb_write(int f, SocketPair  _pair, void*& _scr);
int  adb_lseek(int  fd, int  pos, int  where);
int  adb_close(int f, SocketPair  _pair);

/* packet allocator */
apacket *get_apacket(atransport *t = NULL);
void put_apacket(apacket* &p, atransport *t = NULL);

int	read_packet(int f, SocketPair  _pair, apacket*& packet);
int	write_packet(int f, SocketPair  _pair, apacket*& packet);

int check_header(apacket *p);
int check_data(apacket *p);

void handle_online(atransport *t);
void handle_offline(atransport *t);

void send_packet(apacket* &p, atransport *t);
void send_ready(unsigned local, unsigned remote, atransport *t);
void send_close(unsigned local, unsigned remote, atransport *t);

size_t fill_connect_data(char *buf, size_t bufsize);

void send_auth_request(atransport *t);
void send_auth_response(uint8_t *token, size_t token_size, atransport *t);
void send_auth_publickey(atransport *t);

void adb_auth_verified(atransport *t);

char *connection_state_name(atransport *t);

void qual_overwrite(char **dst, const char *src);

char *adb_strtok_r(char *s, const char *delim, char **last);

void parse_banner(char *banner, atransport *t);

void handle_packet(apacket* &p, atransport *t);

void *output_thread(void *_t);
void *input_thread(void *_t);
void transport_registration_func(atransport *t, int action);

void *user_thread(void *_t);///�û��������

//�û����������
void bip_user_remove_add(int _bip, atransport* t);		//����ͨ��ɾ������
void bip_user_remove_del(int _bip, atransport* t);		//ɾ��������ָ��ͨ��
int  bip_user_remove_exist(int _bip, atransport* t);	//ɾ�������Ƿ����ָ��ͨ�� ��0 ��ʾ����

int remote_socket_enqueue(BipBuffer userbip, atransport* t, apacket *p);
void remote_socket_ready(BipBuffer userbip, atransport* t);
void remote_socket_close(int remote_arg0, int bip_arg1, atransport* t);
void connect_to_remote(BipBuffer userbip, atransport* t, const char *destination);

void adb_set_bipbuffer_type(int _type, BipBuffer userbip, atransport* t);			//Ҫת��������ͨ������ǰҪ�ȹر�ԭ����ͨ��
int adb_shell_send(BipBuffer userbip, atransport* t, const char *destination, int len);
int adb_shell_recv(BipBuffer userbip, atransport* t, sstring &ret, int wait_times = 0);	//�ȴ�ʱ�䣨�룩

void local_socket_faile_notify(const char* msgstr, int bip);
void local_socket_ready_notify(int remote, int bip);
int local_socket_enqueue(int bip_arg1, apacket *p);
void local_socket_close(BipBuffer userbip, atransport* t);	//�ر�ͨ��
//forward
int adb_forward_connect(const char* remote_connect, BipBuffer userbip, atransport* t);
int adb_forward_write(void* sendData, int len, BipBuffer userbip, atransport* t);	//��������
int adb_forward_read(unsigned char* retData, int len, BipBuffer userbip, atransport* t, int wait_times = 0);	//����һ�����ȣ� β����η������һ������ָ�뱣��δ��������� ��ȴ�ʱ��(��)
int adb_forward_disconnect(BipBuffer userbip, atransport* t);

//sync �ļ�����
int adb_sync_connect(BipBuffer userbip, atransport* t);
int adb_sync_write(void* sendData, int len, BipBuffer userbip, atransport* t);
int adb_sync_read(unsigned char* retData, int len, BipBuffer userbip, atransport* t, int wait_times = 0);	//����һ�����ȣ� β����η������һ������ָ�뱣��δ��������� ��ȴ�ʱ��(��)
int adb_sync_read_to_buffer(bufferstream &buffer, int len, BipBuffer userbip, atransport* t, int wait_times = 0);	//����һ�����ȣ� β����η������һ������ָ�뱣��δ��������� ��ȴ�ʱ��(��)
int adb_sync_disconnect(BipBuffer userbip, atransport* t);

int adb_sync_push(const char* lpath, const char* rpath, BipBuffer userbip, atransport* t);
int adb_sync_push_buffer(void* buffer, size_t len, const char* rpath, BipBuffer userbip, atransport* t);
int adb_sync_pull(const char* rpath, const char* lpath, BipBuffer userbip, atransport* t);
int adb_sync_pull_buffer(bufferstream &buffer, size_t &len, const char* rpath, BipBuffer userbip, atransport* t);
#endif	//_ADB_FUNC_H_